package com.example.demo;


import com.example.demo.entity.User;
import com.example.demo.exception.InvalidCredentialsException;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testRegisterUser() {
        User user = new User();
        when(userRepository.save(user)).thenReturn(user);
        assertEquals(user, userService.registerUser(user));
    }

    @Test
    public void testLoginSuccess() {
        User user = new User();
        user.setPassword("pass");

        when(userRepository.findByEmail("email@test.com")).thenReturn(Optional.of(user));

        assertEquals(user, userService.login("email@test.com", "pass"));
    }

    @Test
    public void testLoginFailure() {
        User user = new User();
        user.setPassword("correct");

        when(userRepository.findByEmail("email@test.com")).thenReturn(Optional.of(user));

        assertThrows(InvalidCredentialsException.class,
                () -> userService.login("email@test.com", "wrong"));
    }

    @Test
    public void testGetAllUsers() {
        List<User> list = List.of(new User(), new User());
        when(userRepository.findAll()).thenReturn(list);
        assertEquals(2, userService.getAllUsers().size());
    }

    @Test
    public void testGetUserByIdNotFound() {
        when(userRepository.findById(9L)).thenReturn(Optional.empty());
        assertThrows(UserNotFoundException.class, () -> userService.getUserById(9L));
    }

    @Test
    public void testUpdateUserSuccess() {
        User existing = new User();
        existing.setId(1L);
        existing.setName("Old");

        User updated = new User();
        updated.setName("New");

        when(userRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(userRepository.save(any(User.class))).thenReturn(existing);

        User result = userService.updateUser(1L, updated);
        assertEquals("New", result.getName());
    }

    @Test
    public void testDeleteUserSuccess() {
        when(userRepository.existsById(1L)).thenReturn(true);
        doNothing().when(userRepository).deleteById(1L);
        userService.deleteUser(1L);
        verify(userRepository, times(1)).deleteById(1L);
    }

    @Test
    public void testDeleteUserNotFound() {
        when(userRepository.existsById(1L)).thenReturn(false);
        assertThrows(UserNotFoundException.class, () -> userService.deleteUser(1L));
    }
}
