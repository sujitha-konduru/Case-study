package com.example.demo;


import com.example.demo.entity.Proposal;
import com.example.demo.entity.User;
import com.example.demo.enums.ProposalStatus;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.repository.ProposalRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.ProposalService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.time.LocalDate;
import java.util.Optional;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ProposalServiceTest {

    @Mock
    private ProposalRepository proposalRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private ProposalService proposalService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testSubmitProposalSuccess() {
        Proposal proposal = new Proposal();
        proposal.setVehicleType("truck");
        proposal.setPolicyPackage("premium");

        User user = new User();
        user.setId(1L);

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(proposalRepository.save(any(Proposal.class))).thenAnswer(i -> i.getArguments()[0]);

        Proposal result = proposalService.submitProposal(1L, proposal);

        assertEquals(ProposalStatus.PROPOSAL_SUBMITTED, result.getStatus());
        assertNotNull(result.getSubmissionDate());
        assertEquals(12500, result.getPremiumAmount());
    }

    @Test
    public void testGetProposalById() {
        Proposal proposal = new Proposal();
        proposal.setId(5L);
        when(proposalRepository.findById(5L)).thenReturn(Optional.of(proposal));
        assertEquals(5L, proposalService.getProposalById(5L).getId());
    }

    @Test
    public void testApproveProposal() {
        Proposal proposal = new Proposal();
        proposal.setStatus(ProposalStatus.PROPOSAL_SUBMITTED);

        when(proposalRepository.findById(1L)).thenReturn(Optional.of(proposal));
        when(proposalRepository.save(proposal)).thenReturn(proposal);

        Proposal result = proposalService.approveProposal(1L);
        assertEquals(ProposalStatus.QUOTE_GENERATED, result.getStatus());
    }

    @Test
    public void testRejectProposal() {
        Proposal proposal = new Proposal();
        proposal.setStatus(ProposalStatus.PROPOSAL_SUBMITTED);

        when(proposalRepository.findById(1L)).thenReturn(Optional.of(proposal));
        when(proposalRepository.save(proposal)).thenReturn(proposal);

        Proposal result = proposalService.rejectProposal(1L);
        assertEquals(ProposalStatus.EXPIRED, result.getStatus());
    }

    @Test
    public void testGenerateQuoteWithoutApproval() {
        Proposal proposal = new Proposal();
        proposal.setStatus(ProposalStatus.PROPOSAL_SUBMITTED);

        when(proposalRepository.findById(1L)).thenReturn(Optional.of(proposal));

        assertThrows(IllegalStateException.class, () -> proposalService.generateQuote(1L));
    }

    
}

