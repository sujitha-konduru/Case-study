package com.example.demo.config;

import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.Components;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class SwaggerConfig {

    private static final String SECURITY_SCHEME_NAME = "BearerAuth";

    @Bean
    @Primary
    public OpenAPI insuranceOpenAPI() {
        return new OpenAPI()
            .info(new Info()
                .title("Vehicle Insurance Management API")
                .description("Spring Boot backend for managing vehicle insurance policies, proposals, and users with JWT authentication.")
                .version("v1.0.0")
                .contact(new Contact()
                    .name("Support Team")
                    .email("support@insuranceapp.com")
                    .url("https://insuranceapp.com"))
                .license(new License()
                    .name("Apache 2.0")
                    .url("https://www.apache.org/licenses/LICENSE-2.0.html"))
            )
            .externalDocs(new ExternalDocumentation()
                .description("GitHub Repository")
                .url("https://github.com/your-repo"))
            .addSecurityItem(new SecurityRequirement().addList(SECURITY_SCHEME_NAME))
            .components(new Components()
                .addSecuritySchemes(SECURITY_SCHEME_NAME,
                    new SecurityScheme()
                        .name("Authorization")
                        .description("Enter JWT token as: `Bearer <token>`")
                        .type(SecurityScheme.Type.HTTP)
                        .scheme("bearer")
                        .bearerFormat("JWT")));
    }
}
