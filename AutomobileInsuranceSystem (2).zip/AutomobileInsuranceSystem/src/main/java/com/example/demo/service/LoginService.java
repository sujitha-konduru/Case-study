package com.example.demo.service;

import com.example.demo.dto.LoginRequest;
import com.example.demo.dto.SignupRequest;
import com.example.demo.dto.SignupResponse;
import com.example.demo.entity.Officer;
import com.example.demo.entity.User;
import com.example.demo.repository.LoginRepository;
import com.example.demo.repository.OfficerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LoginService {

    @Autowired
    private LoginRepository loginRepository;

    @Autowired
    private OfficerRepository officerRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public Optional<User> findUserByEmail(String email) {
        return loginRepository.findByEmail(email);
    }

    public Optional<Officer> findOfficerByEmail(String email) {
        return officerRepository.findByEmail(email);
    }

    public String getRoleByEmail(String email) {
        Optional<User> user = loginRepository.findByEmail(email);
        if (user.isPresent()) return user.get().getRole();

        Optional<Officer> officer = officerRepository.findByEmail(email);
        if (officer.isPresent()) return officer.get().getRole();

        throw new RuntimeException("No user or officer found with email: " + email);
    }

    public Long getUserIdByEmail(String email) {
        Optional<User> user = loginRepository.findByEmail(email);
        if (user.isPresent()) return user.get().getId();

        Optional<Officer> officer = officerRepository.findByEmail(email);
        if (officer.isPresent()) return officer.get().getId();

        throw new RuntimeException("No user or officer found with email: " + email);
    }

    public SignupResponse doRegister(SignupRequest request) {
        Optional<User> existingUser = loginRepository.findByEmail(request.getEmail());

        SignupResponse response = new SignupResponse();

        if (existingUser.isPresent()) {
            response.setMessage("User already exists with email: " + request.getEmail());
            return response;
        }

        User user = new User();
        user.setName(request.getName());
        user.setAddress(request.getAddress());
        user.setDateOfBirth(request.getDateOfBirth());
        user.setAadhaarNumber(request.getAadhaarNumber());
        user.setPanNumber(request.getPanNumber());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole("ROLE_USER");

        loginRepository.save(user);

        response.setMessage("User created successfully with ID: " + user.getId());
        response.setEmail(user.getEmail());
        response.setRole(user.getRole());

        return response;
    }
}
