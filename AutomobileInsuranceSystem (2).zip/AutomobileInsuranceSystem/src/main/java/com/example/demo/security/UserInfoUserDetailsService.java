package com.example.demo.security;

import com.example.demo.entity.Officer;
import com.example.demo.entity.User;
import com.example.demo.repository.LoginRepository;
import com.example.demo.repository.OfficerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserInfoUserDetailsService implements UserDetailsService {

    @Autowired
    private LoginRepository loginRepository; // This is for User

    @Autowired
    private OfficerRepository officerRepository; // This is for Officer

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<User> userOpt = loginRepository.findByEmail(username);
        if (userOpt.isPresent()) {
            return new UserInfoUserDetails(userOpt.get(), "ROLE_USER");
        }

        Optional<Officer> officerOpt = officerRepository.findByEmail(username);
        if (officerOpt.isPresent()) {
            return new UserInfoUserDetails(officerOpt.get(), "ROLE_OFFICER");
        }

        throw new UsernameNotFoundException("User or Officer not found with email: " + username);
    }
}
