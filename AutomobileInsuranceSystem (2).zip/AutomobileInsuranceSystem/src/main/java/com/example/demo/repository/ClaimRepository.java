package com.example.demo.repository;


import com.example.demo.entity.Claim;
import com.example.demo.entity.User;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClaimRepository extends JpaRepository<Claim, Long> {
	List<Claim> findByUserId(Long userId);
 // You can add custom query methods here if needed
}

