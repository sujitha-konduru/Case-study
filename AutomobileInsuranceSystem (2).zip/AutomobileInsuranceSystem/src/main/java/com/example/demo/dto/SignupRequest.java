package com.example.demo.dto;


import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class SignupRequest {

    private String name;
    private String address;
    private LocalDate dateOfBirth; // Will be used to calculate age
    private String aadhaarNumber;
    private String panNumber;
    private String email;
    private String password;
}
