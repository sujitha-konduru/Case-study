package com.example.demo.dto;


import java.util.List;

public class DashboardResponse {

    private String welcomeMessage;
    private String userName;
    private String role;

    private int totalPolicies;
    private int activePolicies;
    private int expiredPolicies;

    private List<String> recentActivity; // Optional: e.g., ["Proposal submitted", "Premium paid"]

    // Constructors
    public DashboardResponse() {}

    public DashboardResponse(String welcomeMessage, String userName, String role,
                             int totalPolicies, int activePolicies, int expiredPolicies,
                             List<String> recentActivity) {
        this.welcomeMessage = welcomeMessage;
        this.userName = userName;
        this.role = role;
        this.totalPolicies = totalPolicies;
        this.activePolicies = activePolicies;
        this.expiredPolicies = expiredPolicies;
        this.recentActivity = recentActivity;
    }

    // Getters and Setters

    public String getWelcomeMessage() {
        return welcomeMessage;
    }

    public void setWelcomeMessage(String welcomeMessage) {
        this.welcomeMessage = welcomeMessage;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public int getTotalPolicies() {
        return totalPolicies;
    }

    public void setTotalPolicies(int totalPolicies) {
        this.totalPolicies = totalPolicies;
    }

    public int getActivePolicies() {
        return activePolicies;
    }

    public void setActivePolicies(int activePolicies) {
        this.activePolicies = activePolicies;
    }

    public int getExpiredPolicies() {
        return expiredPolicies;
    }

    public void setExpiredPolicies(int expiredPolicies) {
        this.expiredPolicies = expiredPolicies;
    }

    public List<String> getRecentActivity() {
        return recentActivity;
    }

    public void setRecentActivity(List<String> recentActivity) {
        this.recentActivity = recentActivity;
    }
}
