import { Component } from '@angular/core';
import { InvoiceService } from '../../../services/invoice.service';

@Component({
  selector: 'app-invoice.component',
  standalone: false,
  templateUrl: './invoice.component.html',
  styleUrl: './invoice.component.css'
})

export class InvoiceComponent {
  paymentId!: number;
  isDownloading = false;

  constructor(private paymentService: InvoiceService) {}

  downloadInvoice(paymentId: number) {
    if (!paymentId) return;
    this.isDownloading = true;
    this.paymentService.downloadInvoice(paymentId).subscribe({
      next: response => {
        const blob = new Blob([response.body!], { type: 'application/pdf' });
        let filename = 'invoice.pdf';
        const contentDisposition = response.headers.get('Content-Disposition');
        const matches = /filename="(.+)"/.exec(contentDisposition ?? '');
        if (matches && matches[1]) filename = matches[1];

        const link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = filename;
        link.click();
        this.isDownloading = false;
      },
      error: err => {
        console.error('Error downloading invoice', err);
        this.isDownloading = false;
      }
    });
  }
}
