import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProposalService } from '../../../services/proposal.service';

@Component({
  selector: 'app-proposal-form.component',
  standalone: false,
  templateUrl: './proposal-form.component.html',
  styleUrl: './proposal-form.component.css'
})
export class ProposalFormComponent {
  proposalForm!: FormGroup;

  constructor(
  private fb: FormBuilder,
  private proposalService: ProposalService
) {
  this.proposalForm = this.fb.group({
    vehicleType: ['', Validators.required],
    vehicleModel: ['', Validators.required],
    vehicleNumber: ['', Validators.required],
    purchaseDate: ['', Validators.required],
    policyPackage: ['', Validators.required], // ✅ FIXED
    premiumAmount: [{ value: 0, disabled: true }, Validators.required]
  });

  // ⛳ Move valueChanges subscription OUTSIDE the form group definition
  this.proposalForm.get('policyPackage')?.valueChanges.subscribe(policyPackage => {
  this.calculatePremium(policyPackage);
});

}

  calculatePremium(packageType: string) {
    let premium = 0;
    switch (packageType) {
      case 'Basic':
        premium = 2000;
        break;
      case 'Standard':
        premium = 3500;
        break;
      case 'Premium':
        premium = 5000;
        break;
    }
    this.proposalForm.patchValue({ premiumAmount: premium });
  }


 submitProposal() {
    const userId = Number(localStorage.getItem('userId'));
    if (this.proposalForm.valid) {
      const proposal = this.proposalForm.getRawValue(); // because premiumAmount is disabled
      this.proposalService.submitProposal(proposal, userId)
        .subscribe({
          next: () => {
            alert('Proposal submitted successfully');
            this.proposalForm.reset();
          },
          error: (err) => {
  console.error('Submission Error:', err);
  alert('Failed to submit proposal: ' + (err.error?.message || err.message || 'Unknown error'));
}

        });
    }
  }
}