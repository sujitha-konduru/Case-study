import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';


@Component({
  selector: 'app-user-dashboard.component',
  standalone: false,
  templateUrl: './user-dashboard.component.html',
  styleUrl: './user-dashboard.component.css'
})


export class UserDashboardComponent implements OnInit {
  proposals: any[] = [];
  showPayments: boolean = false; // 🆕 Toggle flag


  constructor(private http: HttpClient,private router: Router) {}

  ngOnInit(): void {
    this.fetchProposals();
  }
  togglePayments() {
    this.showPayments = !this.showPayments;
  }


  getAuthHeaders() {
    const token = localStorage.getItem('token');
    return {
      headers: new HttpHeaders({
        Authorization: `Bearer ${token}`
      })
    };
  }

  fetchProposals() {
  const userId = localStorage.getItem('userId');
  if (!userId) {
    alert('User ID not found. Please log in again.');
    return;
  }

  this.http.get<any[]>(`http://localhost:8888/proposals/user/${userId}`, this.getAuthHeaders())
    .subscribe(data => {
      this.proposals = data;
    });
}
logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('role');
  localStorage.removeItem('userId');
  this.router.navigate(['/login']); // Navigate to login page
}


  submitPayment(proposalId: number, transactionId: string) {
  if (!transactionId || transactionId.trim() === '') {
    alert('Please enter a valid transaction ID');
    return;
  }

  const userId = localStorage.getItem('userId');
  if (!userId) {
    alert('User ID not found. Please log in again.');
    return;
  }

  const url = `http://localhost:8888/quotes/pay/${proposalId}`;
  const body = {
    transactionId,
    userId: parseInt(userId) // Ensure it's a number
  };

  this.http.post(url, body, this.getAuthHeaders())
    .subscribe({
      next: (res: any) => {
        alert('Payment successful! Policy is now ACTIVE.');
        this.fetchProposals(); // Refresh list
      },
      error: (err) => {
        console.error('Payment error:', err);
        alert('Payment failed. Try again.');
      }
    });
  }
}
