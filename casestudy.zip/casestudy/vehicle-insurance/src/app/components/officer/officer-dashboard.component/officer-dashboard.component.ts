import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-officer-dashboard.component',
  standalone: false,
  templateUrl: './officer-dashboard.component.html',
  styleUrl: './officer-dashboard.component.css'
})
export class OfficerDashboardComponent {
  proposals: any[] = [];
  claims: any[] = [];

  showProposals: boolean = false;
  showClaims: boolean = false;

  constructor(private http: HttpClient, private router: Router) {}

  private getAuthHeaders() {
    const token = localStorage.getItem('token');
    return {
      headers: new HttpHeaders({
        Authorization: `Bearer ${token}`
      })
    };
  }

  viewProposals() {
    this.showProposals = true;
    this.showClaims = false;

    this.http.get<any[]>('http://localhost:8888/officer/proposals', this.getAuthHeaders())
      .subscribe(data => {
        this.proposals = data;
      });
  }

  viewClaims() {
    this.showClaims = true;
    this.showProposals = false;

    this.http.get<any[]>('http://localhost:8888/api/payments/claims', this.getAuthHeaders())
      .subscribe(data => {
        this.claims = data;
      });
  }

  updateProposalStatus(proposalId: number, status: string) {
    const url = status === 'APPROVED'
      ? `http://localhost:8888/officer/approve/${proposalId}`
      : `http://localhost:8888/officer/reject/${proposalId}`;

    this.http.put(url, {}, this.getAuthHeaders()).subscribe(() => {
      alert(`Proposal ${proposalId} ${status.toLowerCase()}`);
      this.viewProposals(); // Refresh proposals list
    });
  }

  updateClaimStatus(claimId: number, status: string) {
    const url = `http://localhost:8888/api/payments/claim/${claimId}/status`;
    const body = { status };

    this.http.put(url, body, this.getAuthHeaders()).subscribe({
      next: () => {
        alert(`✅ Claim ${claimId} ${status.toLowerCase()} successfully.`);
        this.viewClaims(); // Refresh claims list
      },
      error: (err) => {
        alert('❌ Failed to update claim status: ' + (err.error?.message || err.message));
      }
    });
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }
}
