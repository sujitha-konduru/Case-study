import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-officer-register.component',
  standalone: false,
  templateUrl: './officer-register.component.html',
  styleUrl: './officer-register.component.css'
})

export class OfficerRegisterComponent {
  officerForm: FormGroup;

  constructor(private fb: FormBuilder, private http: HttpClient, private router: Router) {
    this.officerForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  register() {
    if (this.officerForm.valid) {
      this.http.post('http://localhost:8888/officers/register', this.officerForm.value)
        .subscribe({
          next: () => {
            alert('Officer registered successfully');
            this.router.navigate(['/login']);
          },
          error: () => alert('Registration failed')
        });
    }
  }
}
