import { Component } from '@angular/core';

@Component({
  selector: 'app-reject-proposal.component',
  standalone: false,
  templateUrl: './reject-proposal.component.html',
  styleUrl: './reject-proposal.component.css'
})
export class RejectProposalComponent {

}
