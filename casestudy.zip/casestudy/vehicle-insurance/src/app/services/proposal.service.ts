import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Proposal } from '../models/proposal.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProposalService {
  private baseUrl = 'http://localhost:8888/proposals';

  constructor(private http: HttpClient) {}

  submitProposal(proposal: Proposal, userId: number): Observable<any> {
    return this.http.post(`${this.baseUrl}/submit/${userId}`, proposal);
  }

  getUserProposals(userId: number): Observable<Proposal[]> {
    return this.http.get<Proposal[]>(`${this.baseUrl}/user/${userId}`);
  }
  getProposalById(id: number): Observable<Proposal> {
    return this.http.get<Proposal>(`${this.baseUrl}/${id}`);
  }
}
