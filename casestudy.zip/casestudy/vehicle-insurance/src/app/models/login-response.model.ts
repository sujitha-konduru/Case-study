export interface LoginResponse {
  token: string;
  role: string;
  userId: number;
}
