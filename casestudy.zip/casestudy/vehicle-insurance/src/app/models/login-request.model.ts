export interface LoginRequest {
  email: string;
  password: string;
  role: string; // ✅ add this
}
