export interface Claim {
  id?: number;
  proposalId: number;
  reason: string;
  accidentDate: string;
  claimAmount: number;
  status?: string;
}
