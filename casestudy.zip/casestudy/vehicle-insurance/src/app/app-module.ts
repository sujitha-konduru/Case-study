import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { TokenInterceptor } from './services/token.interceptor';
import { AuthService } from './services/auth.service';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { LoginComponent } from './components/auth/login.component/login.component';
import { RegisterComponent } from './components/auth/register.component/register.component';
import { DashboardComponent } from './components/user/dashboard.component/dashboard.component';
import { ProposalFormComponent } from './components/user/proposal-form.component/proposal-form.component';
import { ClaimFormComponent } from './components/user/claim-form.component/claim-form.component';
import { InvoiceComponent } from './components/user/invoice.component/invoice.component';
import { OfficerDashboardComponent } from './components/officer/officer-dashboard.component/officer-dashboard.component';
import { ProposalReviewComponent } from './components/officer/proposal-review.component/proposal-review.component';
import { RejectProposalComponent } from './components/officer/reject-proposal.component/reject-proposal.component';
import { UserDashboardComponent } from './components/user/user-dashboard.component/user-dashboard.component';
import { ProposalService } from './services/proposal.service';
import { PaymentComponent } from './components/user/payment.component/payment.component';
import { ClaimStatusComponent } from './components/user/claim-status.component/claim-status.component';
import { OfficerRegisterComponent } from './components/officer/officer-register.component/officer-register.component';
import { UserClaimComponent } from './components/user/user-claim.component/user-claim.component';
import { HomeComponent } from './components/home.component/home.component';

@NgModule({
  declarations: [
    App,
    LoginComponent,
    RegisterComponent,
    DashboardComponent,
    ProposalFormComponent,
    ClaimFormComponent,
    InvoiceComponent,
    OfficerDashboardComponent,
    ProposalReviewComponent,
    RejectProposalComponent,
    UserDashboardComponent,
    PaymentComponent,
    ClaimStatusComponent,
    OfficerRegisterComponent,
    UserClaimComponent,
    HomeComponent
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule

  ],
  providers: [
    AuthService,
    { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true },
    ProposalService
    ],
  bootstrap: [App]
})
export class AppModule { }
