package com.example.demo;



import com.example.demo.dto.SignupRequest;
import com.example.demo.dto.SignupResponse;
import com.example.demo.entity.Officer;
import com.example.demo.entity.User;
import com.example.demo.repository.LoginRepository;
import com.example.demo.repository.OfficerRepository;
import com.example.demo.service.LoginService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LoginServiceTest {

    @Mock
    private LoginRepository loginRepository;

    @Mock
    private OfficerRepository officerRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private LoginService loginService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindUserByEmail() {
        String email = "test@example.com";
        User user = new User();
        user.setEmail(email);

        when(loginRepository.findByEmail(email)).thenReturn(Optional.of(user));

        Optional<User> result = loginService.findUserByEmail(email);
        assertTrue(result.isPresent());
        assertEquals(email, result.get().getEmail());
    }

    @Test
    void testGetRoleByEmail_UserExists() {
        String email = "user@example.com";
        User user = new User();
        user.setEmail(email);
        user.setRole("ROLE_USER");

        when(loginRepository.findByEmail(email)).thenReturn(Optional.of(user));

        String role = loginService.getRoleByEmail(email);
        assertEquals("ROLE_USER", role);
    }

    @Test
    void testGetRoleByEmail_OfficerExists() {
        String email = "officer@example.com";
        Officer officer = new Officer();
        officer.setEmail(email);
        officer.setRole("ROLE_OFFICER");

        when(loginRepository.findByEmail(email)).thenReturn(Optional.empty());
        when(officerRepository.findByEmail(email)).thenReturn(Optional.of(officer));

        String role = loginService.getRoleByEmail(email);
        assertEquals("ROLE_OFFICER", role);
    }

    @Test
    void testGetRoleByEmail_NotFound() {
        String email = "notfound@example.com";
        when(loginRepository.findByEmail(email)).thenReturn(Optional.empty());
        when(officerRepository.findByEmail(email)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> loginService.getRoleByEmail(email));

        assertEquals("No user or officer found with email: " + email, exception.getMessage());
    }

    
    @Test
    void testDoRegisterSuccess() {
        SignupRequest request = new SignupRequest();
        request.setName("John Doe");
        request.setEmail("john@example.com");
        request.setPassword("password");
        request.setAddress("123 Street");
        request.setDateOfBirth(LocalDate.of(1990, 1, 1));
        request.setAadhaarNumber("123456789012");
        request.setPanNumber("ABCDE1234F");

        // Simulate no existing user
        when(loginRepository.findByEmail("john@example.com")).thenReturn(Optional.empty());

        // Simulate saved user with ID
        // Note: must match the instance returned by .save()
        when(loginRepository.save(any(User.class))).thenAnswer(invocation -> {
            User user = invocation.getArgument(0);
            user.setId(100L); // Simulate DB-generated ID
            return user;
        });

        // Call service
        SignupResponse response = loginService.doRegister(request);

        // Assert
        assertEquals("User created successfully with ID: 100", response.getMessage());
        assertEquals("john@example.com", response.getEmail());
        assertEquals("ROLE_USER", response.getRole());
    }

 
}

