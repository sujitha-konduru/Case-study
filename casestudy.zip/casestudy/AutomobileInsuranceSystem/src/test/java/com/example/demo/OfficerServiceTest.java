package com.example.demo;


import com.example.demo.entity.Officer;
import com.example.demo.exception.InvalidCredentialsException;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.repository.OfficerRepository;
import com.example.demo.service.OfficerService;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;
import java.util.List;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class OfficerServiceTest {

    @Mock
    private OfficerRepository officerRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private OfficerService officerService;

    public OfficerServiceTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testRegisterOfficer() {
        Officer officer = new Officer();
        officer.setPassword("plain");

        when(passwordEncoder.encode("plain")).thenReturn("encoded");
        when(officerRepository.save(any(Officer.class))).thenReturn(officer);

        Officer saved = officerService.registerOfficer(officer);
        assertEquals("encoded", saved.getPassword());
    }

    @Test
    public void testLoginSuccess() {
        Officer officer = new Officer();
        officer.setEmail("test@example.com");
        officer.setPassword("encoded");

        when(officerRepository.findByEmail("test@example.com")).thenReturn(Optional.of(officer));
        when(passwordEncoder.matches("plain", "encoded")).thenReturn(true);

        Officer result = officerService.login("test@example.com", "plain");
        assertEquals("test@example.com", result.getEmail());
    }

    @Test
    public void testLoginFail_InvalidPassword() {
        Officer officer = new Officer();
        officer.setPassword("encoded");

        when(officerRepository.findByEmail("test@example.com")).thenReturn(Optional.of(officer));
        when(passwordEncoder.matches("wrong", "encoded")).thenReturn(false);

        assertThrows(InvalidCredentialsException.class, () -> officerService.login("test@example.com", "wrong"));
    }

    @Test
    public void testGetOfficerByIdSuccess() {
        Officer officer = new Officer();
        officer.setId(1L);

        when(officerRepository.findById(1L)).thenReturn(Optional.of(officer));
        Officer result = officerService.getOfficerById(1L);
        assertEquals(1L, result.getId());
    }

    @Test
    public void testDeleteOfficer_NotFound() {
        when(officerRepository.existsById(99L)).thenReturn(false);
        assertThrows(UserNotFoundException.class, () -> officerService.deleteOfficer(99L));
    }

    @Test
    public void testGetAllOfficers() {
        List<Officer> officers = Arrays.asList(new Officer(), new Officer());
        when(officerRepository.findAll()).thenReturn(officers);

        assertEquals(2, officerService.getAllOfficers().size());
    }
}
