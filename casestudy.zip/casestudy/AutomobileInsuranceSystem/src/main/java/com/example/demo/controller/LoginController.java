package com.example.demo.controller;

import com.example.demo.dto.*;
import com.example.demo.entity.Officer;
import com.example.demo.entity.User;
import com.example.demo.security.JWTService;
import com.example.demo.service.DashboardService;
import com.example.demo.service.LoginService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class LoginController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JWTService jwtService;

    @Autowired
    private LoginService loginService;
    @Autowired
    private PasswordEncoder passwordEncoder;


    @Autowired
    private DashboardService dashboardService;

    @PostMapping("/doLogin")
    @Operation(summary = "Login endpoint for user or officer")
    public ResponseEntity<LoginResponse> loginUser(@RequestBody LoginRequest request) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            request.getEmail(),
                            request.getPassword()
                    )
            );

            String token = jwtService.generateToken(request.getEmail());

            // Determine role and ID
            String requestedRole = request.getRole().toUpperCase();
            if ("ROLE_USER".equals(requestedRole)) {
                User user = loginService.findUserByEmail(request.getEmail())
                        .orElseThrow(() -> new UsernameNotFoundException("User not found"));
                return ResponseEntity.ok(new LoginResponse(token, "ROLE_USER", user.getId()));
            } else if ("ROLE_OFFICER".equals(requestedRole)) {
                var officer = loginService.findOfficerByEmail(request.getEmail())
                        .orElseThrow(() -> new UsernameNotFoundException("Officer not found"));
                return ResponseEntity.ok(new LoginResponse(token, "ROLE_OFFICER", officer.getId()));
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new LoginResponse(null, null, null, "Invalid role specified"));
            }

        } catch (BadCredentialsException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new LoginResponse(null, null, null, "Invalid email or password"));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new LoginResponse(null, null, null, "Internal server error"));
        }
        
    }
    @GetMapping("/dashboard/login")
    @Operation(summary = "Returns dashboard data (secured)", 
               security = @SecurityRequirement(name = "BearerAuth"))
    public ResponseEntity<DashboardResponse> dashboard() {
        return new ResponseEntity<>(dashboardService.getDashboardData(), HttpStatus.OK);
    }

    @PostMapping("/doRegister")
    @Operation(summary = "Register a new user")
    public ResponseEntity<SignupResponse> doRegister(@RequestBody SignupRequest request) {
        return new ResponseEntity<>(loginService.doRegister(request), HttpStatus.CREATED);
    }
}
