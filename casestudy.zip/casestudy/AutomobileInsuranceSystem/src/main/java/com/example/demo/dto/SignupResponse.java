package com.example.demo.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SignupResponse {

    private String message;
    private String email;
    private String role;
    public SignupResponse() {
    }


    public SignupResponse(String message, String email, String role) {
        this.message = message;
        this.email = email;
        this.role = role;
    }
}

