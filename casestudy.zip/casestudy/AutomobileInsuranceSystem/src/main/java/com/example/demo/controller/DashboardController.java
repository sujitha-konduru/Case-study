package com.example.demo.controller;



import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@SecurityRequirement(name = "BearerAuth")
@RestController
@RequestMapping("/api")
public class DashboardController {

    @GetMapping("/dashboard")
    @Operation(summary = "Returns dashboard data", description = "Access secured dashboard endpoint")
    public ResponseEntity<String> getDashboard() {
        return ResponseEntity.ok("Dashboard Access Granted!");
    }
}
