package com.example.demo.service;

import com.example.demo.entity.Officer;
import com.example.demo.exception.InvalidCredentialsException;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.repository.OfficerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OfficerService {

    @Autowired
    private OfficerRepository officerRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;


    public Officer registerOfficer(Officer officer) {
        officer.setPassword(passwordEncoder.encode(officer.getPassword()));
        return officerRepository.save(officer);
    }

    public Officer login(String email, String rawPassword) {
        Officer officer = officerRepository.findByEmail(email)
            .orElseThrow(() -> new InvalidCredentialsException("Invalid officer credentials."));

        if (!passwordEncoder.matches(rawPassword, officer.getPassword())) {
            throw new InvalidCredentialsException("Invalid officer credentials.");
        }

        return officer;
    }


    public List<Officer> getAllOfficers() {
        return officerRepository.findAll();
    }

    public Officer getOfficerById(Long id) {
        return officerRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("Officer not found with id: " + id));
    }

    public void deleteOfficer(Long id) {
        if (!officerRepository.existsById(id)) {
            throw new UserNotFoundException("Officer not found with id: " + id);
        }
        officerRepository.deleteById(id);
    }
}
