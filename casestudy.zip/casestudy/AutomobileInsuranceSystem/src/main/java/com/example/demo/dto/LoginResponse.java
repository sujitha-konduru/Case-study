package com.example.demo.dto;

public class LoginResponse {
    private String token;
    private String role;
    private Long userId; // 👈 Add this field
    private String message;


    public LoginResponse(String token, String role, Long userId) {
        this.token = token;
        this.role = role;
        this.userId = userId;
    }
    public LoginResponse(String token, String role, Long id, String message) {
        this.token = token;
        this.role = role;
        this.userId = userId;
        this.message = message;
    }

    public String getToken() {
        return token;
    }

    public String getRole() {
        return role;
    }

    public Long getUserId() {
        return userId;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}
