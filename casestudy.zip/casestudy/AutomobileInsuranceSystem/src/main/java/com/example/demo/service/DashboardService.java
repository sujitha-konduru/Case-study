package com.example.demo.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.example.demo.dto.DashboardResponse;
import com.example.demo.entity.User;
import com.example.demo.entity.Proposal;
import com.example.demo.enums.ProposalStatus;
import com.example.demo.repository.UserRepository;

@Service
public class DashboardService {

    @Autowired
    private UserRepository userRepository;

    public DashboardResponse getDashboardData() {
        // Get authenticated user email from SecurityContext
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        // Fetch user from DB
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        List<Proposal> proposals = user.getProposals();

        // Calculate stats
        int totalPolicies = proposals.size();
        int activePolicies = (int) proposals.stream()
                .filter(p -> p.getStatus() == ProposalStatus.ACTIVE)
                .count();

        int expiredPolicies = (int) proposals.stream()
                .filter(p -> p.getStatus() == ProposalStatus.EXPIRED)
                .count();

        List<String> recentActivity = proposals.stream()
                .sorted((p1, p2) -> p2.getCreatedDate().compareTo(p1.getCreatedDate()))
                .limit(5)
                .map(p -> "Policy: " + p.getPolicyPackage() + ", Status: " + p.getStatus().name())
                .collect(Collectors.toList());

        // Build response
        DashboardResponse response = new DashboardResponse();
        response.setWelcomeMessage("Welcome to your Insurance Dashboard!");
        response.setUserName(user.getName());
        response.setRole(user.getRole());
        response.setTotalPolicies(totalPolicies);
        response.setActivePolicies(activePolicies);
        response.setExpiredPolicies(expiredPolicies);
        response.setRecentActivity(recentActivity);

        return response;
    }
}
