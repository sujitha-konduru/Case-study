package com.example.demo.controller;

import com.example.demo.entity.Payment;
import com.example.demo.service.InvoiceService;
import com.example.demo.repository.PaymentRepository;
import com.example.demo.repository.ProposalRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.entity.User;
import com.example.demo.entity.Proposal;
import com.example.demo.repository.ClaimRepository;
import com.example.demo.entity.Claim;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "http://localhost:4200") // Allow Angular frontend

public class PaymentController {

 @Autowired
 private InvoiceService invoiceService;

 @Autowired
 private PaymentRepository paymentRepository;

 @GetMapping("/invoice/{paymentId}")
 public ResponseEntity<FileSystemResource> downloadInvoice(@PathVariable Long paymentId) {
     Payment payment = paymentRepository.findById(paymentId).orElse(null);

     if (payment == null || payment.getUser() == null || payment.getProposal() == null) {
         return ResponseEntity.status(500).body(null); // Avoid infinite recursion or null pointers
     }

     String filename = invoiceService.generateInvoice(payment);
     File file = new File(filename);

     if (!file.exists()) {
         return ResponseEntity.notFound().build();
     }

     FileSystemResource resource = new FileSystemResource(file);
     return ResponseEntity.ok()
             .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + file.getName())
             .contentLength(file.length())
             .contentType(MediaType.APPLICATION_PDF)
             .body(resource);
 }
 @Autowired
 private PaymentRepository paymentRepository1;

 @Autowired
 private UserRepository userRepository;

 @Autowired
 private ProposalRepository proposalRepository;
 @Autowired
 private ClaimRepository claimRepository;

 @PostMapping("/make")
 public ResponseEntity<Map<String, Object>> makePayment(@RequestParam Long userId,
                                                        @RequestParam Long proposalId,
                                                        @RequestParam Double amount) {
     User user = userRepository.findById(userId).orElse(null);
     Proposal proposal = proposalRepository.findById(proposalId).orElse(null);

     if (user == null || proposal == null) {
         Map<String, Object> error = new HashMap<>();
         error.put("message", "Invalid user or proposal ID");
         return ResponseEntity.badRequest().body(error);
     }

     Payment payment = new Payment();
     payment.setUser(user);
     payment.setProposal(proposal);
     payment.setAmount(amount);
     payment.setPaymentDate(LocalDate.now());

     Payment saved = paymentRepository.save(payment);

     Map<String, Object> response = new HashMap<>();
     response.put("message", "Payment recorded successfully");
     response.put("paymentId", saved.getId());

     return ResponseEntity.ok(response);
 }

 @PostMapping("/claim")
 public ResponseEntity<Map<String, Object>> submitClaim(@RequestParam Long userId,
                                                        @RequestParam Long proposalId,
                                                        @RequestParam String reason) {
     User user = userRepository.findById(userId).orElse(null);
     Proposal proposal = proposalRepository.findById(proposalId).orElse(null);

     if (user == null || proposal == null) {
         return ResponseEntity.badRequest().body(Map.of("error", "Invalid user or proposal ID"));
     }

     Claim claim = new Claim();
     claim.setUser(user);
     claim.setProposal(proposal);
     claim.setReason(reason);
     claim.setStatus("PENDING");
     claim.setDateFiled(LocalDate.now());

     claimRepository.save(claim);
     Map<String, Object> response = new HashMap<>();
     response.put("message", "Claim submitted successfully");
     response.put("claimId", claim.getId());
     response.put("status", claim.getStatus());
     response.put("dateFiled", claim.getDateFiled());

     return ResponseEntity.ok(response);

 }
 @GetMapping("/claims/by-user/{userId}")
 public ResponseEntity<List<Claim>> getClaimsByUser(@PathVariable Long userId) {
	 List<Claim> claims = claimRepository.findByUserId(userId);  // ✅
     return ResponseEntity.ok(claims);
 }


 @PutMapping("/claim/{claimId}/status")
 public ResponseEntity<Map<String, String>> updateClaimStatus(@PathVariable Long claimId,
                                                              @RequestBody Map<String, String> request) {
     String status = request.get("status");

     Map<String, String> response = new HashMap<>();

     if (status == null || status.trim().isEmpty()) {
         response.put("error", "Status is missing in the request.");
         return ResponseEntity.badRequest().body(response);
     }

     Claim claim = claimRepository.findById(claimId).orElse(null);
     if (claim == null) {
         response.put("error", "Claim not found with ID: " + claimId);
         return ResponseEntity.status(404).body(response);
     }

     try {
         claim.setStatus(status.toUpperCase());
         claimRepository.save(claim);
         response.put("message", "Claim status updated to: " + status.toUpperCase());
         return ResponseEntity.ok(response);
     } catch (Exception e) {
         response.put("error", "Error updating claim status: " + e.getMessage());
         return ResponseEntity.status(500).body(response);
     }
 }

 
 @GetMapping("/claims")
 public ResponseEntity<List<Claim>> getAllClaims() {
     List<Claim> claims = claimRepository.findAll();
     return ResponseEntity.ok(claims);
 }



}
