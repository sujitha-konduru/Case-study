import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class InvoiceService {

  private baseUrl = 'http://localhost:8888/api/payments'; // Change port if needed

  constructor(private http: HttpClient) {}

  downloadInvoice(paymentId: number) {
    return this.http.get(`${this.baseUrl}/invoice/${paymentId}`, {
      responseType: 'blob', // Important: treat as binary file
      observe: 'response'   // Needed to get filename from headers
    });
  }
}
