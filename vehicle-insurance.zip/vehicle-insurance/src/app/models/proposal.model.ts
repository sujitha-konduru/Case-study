export interface Proposal {
  id?: number;
  vehicleType: string;
  vehicleModel: string;
  vehicleNumber: string;
  purchaseDate: string;
  premiumAmount: number;
  status?: string;
}
