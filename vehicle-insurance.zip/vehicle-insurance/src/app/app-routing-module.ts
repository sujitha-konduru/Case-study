import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/auth/login.component/login.component';
import { RegisterComponent } from './components/auth/register.component/register.component';

import { DashboardComponent } from './components/user/dashboard.component/dashboard.component';
import { ProposalFormComponent } from './components/user/proposal-form.component/proposal-form.component';
import { ClaimFormComponent } from './components/user/claim-form.component/claim-form.component';
import { InvoiceComponent } from './components/user/invoice.component/invoice.component';
import { UserDashboardComponent } from './components/user/user-dashboard.component/user-dashboard.component';
import { PaymentComponent } from './components/user/payment.component/payment.component';
import { ClaimStatusComponent } from './components/user/claim-status.component/claim-status.component';
import { OfficerRegisterComponent } from './components/officer/officer-register.component/officer-register.component';
import { HomeComponent } from './components/home.component/home.component';

import { OfficerDashboardComponent } from './components/officer/officer-dashboard.component/officer-dashboard.component';
import { ProposalReviewComponent } from './components/officer/proposal-review.component/proposal-review.component';
import { RejectProposalComponent } from './components/officer/reject-proposal.component/reject-proposal.component';
const routes: Routes = [
  
  { path: '', component: HomeComponent, pathMatch: 'full' },

  
  // Auth routes
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'submit-proposal', component: ProposalFormComponent },
  { path: 'claim-status', component: ClaimStatusComponent },
  { path: 'officer-register',component:OfficerRegisterComponent},


  // User routes
  {
    path: 'dashboard',
    component: UserDashboardComponent,
    children: [
      { path: '', redirectTo: 'proposal-form', pathMatch: 'full' },
      { path: 'proposal-form', component: ProposalFormComponent },
      { path: 'claim-form', component: ClaimFormComponent },
      { path: 'invoice', component: InvoiceComponent },
      { path: 'payment', component: PaymentComponent },

      { path: '', redirectTo: 'proposal-form', pathMatch: 'full' }
    ]
  },
  // Officer routes
  { path: 'officer-dashboard', component: OfficerDashboardComponent },
  { path: 'proposal-review/:id', component: ProposalReviewComponent },
  { path: 'reject-proposal/:id', component: RejectProposalComponent },

  // Wildcard route for unknown paths
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }



