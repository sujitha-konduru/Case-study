import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RejectProposalComponent } from './reject-proposal.component';

describe('RejectProposalComponent', () => {
  let component: RejectProposalComponent;
  let fixture: ComponentFixture<RejectProposalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RejectProposalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RejectProposalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
