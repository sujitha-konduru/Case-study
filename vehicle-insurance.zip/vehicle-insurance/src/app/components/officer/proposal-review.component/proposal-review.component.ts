import { Component } from '@angular/core';

@Component({
  selector: 'app-proposal-review.component',
  standalone: false,
  templateUrl: './proposal-review.component.html',
  styleUrl: './proposal-review.component.css'
})
export class ProposalReviewComponent {

}
