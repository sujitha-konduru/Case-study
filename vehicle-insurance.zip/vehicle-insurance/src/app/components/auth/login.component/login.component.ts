import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-login.component',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  loginForm!: FormGroup;
  errorMessage = '';
  registerLink: string = '/register'; // ← bind this to routerLink

  constructor(
    private authService: AuthService,
    private router: Router,
    private fb: FormBuilder
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      role: ['USER', Validators.required]
    });

    // changes registration link
    this.loginForm.get('role')?.valueChanges.subscribe(role => {
      this.registerLink = role === 'OFFICER' ? '/officer-register' : '/register';
    });
  }

  login() {
  if (this.loginForm.valid) {
    const formData = { ...this.loginForm.value };

    // ✅ Add the "ROLE_" prefix as required by backend
    formData.role = `ROLE_${formData.role.toUpperCase()}`;

    this.authService.login(formData).subscribe({
      next: (res) => {
        localStorage.setItem('token', res.token);
        localStorage.setItem('role', res.role);
        localStorage.setItem('userId', res.userId.toString());

        alert('Login successful');

        if (res.role === 'ROLE_USER') {
          this.router.navigate(['/dashboard']);
        } else if (res.role === 'ROLE_OFFICER') {
          this.router.navigate(['/officer-dashboard']);
        } else {
          alert('Unknown role');
        }
      },
      error: () => {
        this.errorMessage = 'Invalid credentials';
      }
    });
  }
}
}
