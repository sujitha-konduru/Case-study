import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-claim-status.component',
  standalone: false,
  templateUrl: './claim-status.component.html',
  styleUrl: './claim-status.component.css'
})
export class ClaimStatusComponent implements OnInit {
  claims: any[] = [];
  loading = true;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    const userId = localStorage.getItem('userId');
    const token = localStorage.getItem('token');

    if (!userId || !token) {
      this.loading = false;
      alert('⚠️ You are not logged in. Please login to view claims.');
      return;
    }

    this.http.get<any[]>(`http://localhost:8888/api/payments/claims/by-user/${userId}`, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    }).subscribe({
      next: (data) => {
        this.claims = data;
        this.loading = false;
      },
      error: (err) => {
        this.loading = false;
        alert('❌ Failed to fetch claims: ' + (err.error?.message || err.message));
      }
    });
  }
}
