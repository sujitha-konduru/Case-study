import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-payment.component',
  standalone: false,
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.css'
})
export class PaymentComponent {
  proposalId!: number;
  transactionId!: string;

  amount: number = 5000; // Sample amount or bind from quote
  userId: number = 1; // Replace with actual logged-in userId
  paymentResult: any = null;

  constructor(private http: HttpClient) {}

  makePayment() {
    if (!this.proposalId) {
      alert('Please enter Proposal ID');
      return;
    }

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${localStorage.getItem('token')}`
    });

    this.http.post<any>(
      `http://localhost:8888/api/payments/make?userId=${this.userId}&proposalId=${this.proposalId}&amount=${this.amount}`,
      {}, // No body needed
      { headers }
    ).subscribe({
      next: (response) => {
        this.paymentResult = response;
        alert("✅ Payment recorded.");
      },
      error: (err) => {
        console.error(err);
        alert("❌ Payment failed. Check Proposal ID and try again.");
      }
    });
  }
}
