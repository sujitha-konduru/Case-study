import { Component } from '@angular/core';

@Component({
  selector: 'app-user-claim.component',
  standalone: false,
  templateUrl: './user-claim.component.html',
  styleUrl: './user-claim.component.css'
})
export class UserClaimComponent {

}
