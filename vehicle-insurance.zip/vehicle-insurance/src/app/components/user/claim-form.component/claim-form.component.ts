import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpParams } from '@angular/common/http';
@Component({
  selector: 'app-claim-form.component',
  standalone: false,
  templateUrl: './claim-form.component.html',
  styleUrl: './claim-form.component.css'
})
export class ClaimFormComponent {
  claimForm!: FormGroup;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.claimForm = this.fb.group({
      proposalId: ['', Validators.required],
      reason: ['', Validators.required]
    });
  }

 submitClaim() {
  const userId = localStorage.getItem('userId');
  const token = localStorage.getItem('token');

  if (!userId || !token) {
    alert('❌ You must be logged in to submit a claim.');
    return;
  }

  const form = this.claimForm.value;

  this.http.post<any>(`http://localhost:8888/api/payments/claim`, null, {
    params: {
      userId,
      proposalId: form.proposalId,
      reason: form.reason
    },
    headers: {
      Authorization: `Bearer ${token}`
    }
  }).subscribe({
    next: (response) => {
      alert(`✅ ${response.message}\nClaim ID: ${response.claimId}\nStatus: ${response.status}`);
      this.claimForm.reset();
    },
    error: (err) => {
      alert('❌ Claim submission failed: ' + (err.error?.message || err.message));
    }
  });
}
}
